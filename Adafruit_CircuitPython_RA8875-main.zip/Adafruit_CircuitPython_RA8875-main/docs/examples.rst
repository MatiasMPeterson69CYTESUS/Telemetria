Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/ra8875_simpletest.py
    :caption: examples/ra8875_simpletest.py
    :linenos:


Bitmap test
------------

.. literalinclude:: ../examples/ra8875_bmptest.py
    :caption: examples/ra8875_bmptest.py
    :linenos:
