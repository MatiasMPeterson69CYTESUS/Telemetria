<?php
// Establecer el encabezado Access-Control-Allow-Origin para permitir solicitudes desde cualquier origen
header("Access-Control-Allow-Origin: *");

// Conexión a la base de datos (ajusta según tus credenciales)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sensor_db";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Consulta para obtener la última fila de datos
$sql = "SELECT id, temperature, humidity, datetime FROM dht11 ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);

$data = array();

if ($result->num_rows > 0) {
    // Guardar los datos de la última fila en un array
    $row = $result->fetch_assoc();
    $data[] = $row["temperature"]; // Guardar temperatura
    $data[] = $row["humidity"];    // Guardar humedad
    $data[] = $row["temperature"]; // Guardar temperatura
    $data[] = $row["humidity"];    // Guardar humedad
}

// Devolver los datos en formato JSON
echo json_encode($data);

// Cerrar conexión
$conn->close();
?>
