$(document).ready(function(){
    function updateData() {
        $.ajax({
            url: "http://localhost/Esus/base_datos.php", // Ruta de tu script PHP para obtener datos de la base de datos
            type: "GET",
            success: function(data) {
                // Convertir la cadena JSON en un array JavaScript
                var dataArray = JSON.parse(data);

                // Actualizar los datos en los cuadros
                $('#box1').text(dataArray[0]);
                $('#box2').text(dataArray[1]);
                $('#box3').text(dataArray[2]);
                $('#box4').text(dataArray[3]);
            }
        });
    }

    // Actualizar datos cada 1 segundos
    setInterval(updateData, 5000);
});
