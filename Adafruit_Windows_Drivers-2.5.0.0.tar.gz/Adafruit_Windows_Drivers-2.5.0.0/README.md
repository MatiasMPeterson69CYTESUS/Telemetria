# Adafruit Windows Drivers

All in one Windows driver installer for Adafruit's boards.  **See the [Releases
tab](https://github.com/adafruit/Adafruit_Windows_Drivers/releases) for the latest binary release.**

Note consider this 'beta' as it's only tested on Windows 7, however in theory should support XP through 10.

Requires NSIS 3.0+ to build the installer.

See license.rtf for the license of the software (including 3rd party software
installed with the tool).
